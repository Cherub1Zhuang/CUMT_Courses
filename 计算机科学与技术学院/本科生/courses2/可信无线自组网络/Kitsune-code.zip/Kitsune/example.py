from Kitsune import Kitsune
import numpy as np
import time

# Load Mirai pcap (a recording of the Mirai botnet malware being activated)
# The first 70,000 observations are clean...
# print("Unzipping Sample Capture...")
# import zipfile
# with zipfile.ZipFile("mirai.zip","r") as zip_ref:
#     zip_ref.extractall()

# My TEST
# File location
# path = "part.pcap"  # the pcap, pcapng, or tsv file to process.
# path = "20000.pcap"
# path = "50000.pcap.tsv"
# maxAE = 10  # maximum size for any autoencoder in the ensemble layer
# FMgrace = 700  # 用于学习特征映射的实例数量(集成的架构)
# ADgrace = 10000  # 用于训练异常检测器的实例数量(集成本身

# path = "my_mirai.pcap"  # the pcap, pcapng, or tsv file to process.
path = "mirai_part.pcap"
# path = "mirai.pcap"
# # KitNET params:
maxAE = 10  # maximum size for any autoencoder in the ensemble layer
FMgrace = 5000  # the number of instances taken to learn the feature mapping
ADgrace = 50000  # the number of instances used to train the anomaly detector

packet_limit = np.Inf
# path = "mirai.pcap"
# KitNET params:
# maxAE = 10  ]
# FMgrace = 5000
# ADgrace = 50000

# Build Kitsune
K = Kitsune(path, packet_limit, maxAE, FMgrace, ADgrace)

print("Running Kitsune:")
RMSEs = []
i = 0
start = time.time()
# 处理(训练/执行)每个单独的包
# 在执行process()方法之后，每个观察都被丢弃
while True:
    i += 1
    if i % 1000 == 0:
        print(i)    # 每处理1000个包输出一次
    rmse = K.proc_next_packet()
    if rmse == -1:
        break
    # if rmse != 0.0:
    #     print(rmse)
    RMSEs.append(rmse)
    if rmse > K.max_rmse and rmse != 0.0:
        print(str(i) + " rmse: " + str(rmse))
stop = time.time()
print("Complete. Time elapsed: " + str(stop - start))

# Here we demonstrate how one can fit the RMSE scores to a log-normal distribution (useful for finding/setting a cutoff threshold \phi)
from scipy.stats import norm

benignSample = np.log(RMSEs[FMgrace + ADgrace + 1:100000])
logProbs = norm.logsf(np.log(RMSEs), np.mean(benignSample), np.std(benignSample))

# plot the RMSE anomaly scores
print("Plotting results")
from matplotlib import pyplot as plt
from matplotlib import cm

plt.figure(figsize=(10, 5))
fig = plt.scatter(range(FMgrace + ADgrace + 1, len(RMSEs)), RMSEs[FMgrace + ADgrace + 1:], s=0.1,
                  c=logProbs[FMgrace + ADgrace + 1:], cmap='RdYlGn')
plt.yscale("log")
plt.title("Anomaly Scores from Kitsune's Execution Phase")
plt.ylabel("RMSE (log scaled)")
plt.xlabel("Time elapsed [min]")
plt.annotate('Mirai C&C channel opened [Telnet]', xy=(66661, RMSEs[66661]), xytext=(96661, 1),
             arrowprops=dict(facecolor='black', shrink=0.05), )
# Mirai Bot激活:Mirai扫描网络中易受攻击的设备
plt.annotate('Mirai Bot Activated\nMirai scans network\nfor vulnerable devices', xy=(67661, 10), xytext=(67661, 150),
             arrowprops=dict(facecolor='black', shrink=0.05), )
# Mirai Bot启动DoS攻击
plt.annotate('Mirai Bot launches DoS attack', xy=(79999, 100), xytext=(99999, 1000),
             arrowprops=dict(facecolor='black', shrink=0.05), )
figbar = plt.colorbar()
figbar.ax.set_ylabel('Log Probability\n ', rotation=270)
plt.show()
