import numpy as np
import KitNET.dA as AE
import KitNET.corClust as CC


# KitNET是一个轻量级的在线异常检测算法，基于一组自动编码器

class KitNET:
    """
    n: 输入数据集中的特性数量(i.e., x \in R^n)
    m: 在集成层中任何自动编码器的最大尺寸
    AD_grace_period: 网络在产生异常分数之前将学习的实例数量
    FM_grace_period: 用于学习特征映射的实例数。如果为'None'，则令FM_grace_period=AM_grace_period
    learning_rate: 在KitNET实例中所有autoencoders的默认随机梯度下降学习率
    hidden_ratio: 隐藏神经元与可见神经元的默认比例。例如，0.75会在隐藏层造成大约25%的压缩。
    feature_map: 可以选择提供特征图，而不是学习特征图. 映射必须是一个列表，
                 其中第i个条目包含一个特征索引列表，该列表将与集成中的第i个自动编码器相匹配。
                 例如： [[2,5,3],[4,0,1],[6,7]]
    """

    def __init__(self, n, max_autoencoder_size=10, FM_grace_period=None, AD_grace_period=10000, learning_rate=0.1,
                 hidden_ratio=0.75, feature_map=None):
        # Parameters:
        self.AD_grace_period = AD_grace_period
        if FM_grace_period is None:
            self.FM_grace_period = AD_grace_period
        else:
            self.FM_grace_period = FM_grace_period
        if max_autoencoder_size <= 0:
            self.m = 1
        else:
            self.m = max_autoencoder_size
        self.lr = learning_rate
        self.hr = hidden_ratio
        self.n = n

        # Variables
        self.n_trained = 0  # 到目前为止训练实例的数量
        self.n_executed = 0  # 到目前为止执行的实例的数量
        self.v = feature_map    # 映射

        self.train_rmse = [-1]


        # 没有特征图,则进行FM训练模式
        if self.v is None:
            print("Feature-Mapper: train-mode, Anomaly-Detector: off-mode")
        else:   # 否则为执行模式,然后开始训练AD
            self.__createAD__()
            print("Feature-Mapper: execute-mode, Anomaly-Detector: train-mode")
        # 用于特征映射过程的增量特征cluatering
        self.FM = CC.corClust(self.n)  # incremental feature cluatering for the feature mapping process
        self.ensembleLayer = []
        self.outputLayer = None

    # 如果FM_grace_period+AM_grace_period已经通过，那么这个函数将在x上执行KitNET，否则，这个函数将学习x。
    # x: 一个长度为n的numpy数组
    # Note: KitNET自动对所有属性执行0-1规范化
    def process(self, x):
        if self.n_trained > self.FM_grace_period + self.AD_grace_period:  # 如果FM和AD都处于执行模式
            return self.execute(x)
        else:
            self.train(x)
            return 0.0

    # force train KitNET on x
    # 返回训练时x的异常分数(不用于警告)
    def train(self, x):
        # 如果FM处于训练模式，并且用户没有提供特性映射
        if self.n_trained <= self.FM_grace_period and self.v is None:
            # 更新增量关联矩阵
            self.FM.update(x)
            if self.n_trained == self.FM_grace_period:  # 是否应该实例化特性映射
                self.v = self.FM.cluster(self.m)
                self.__createAD__()
                print("The Feature-Mapper found a mapping: " + str(self.n) + " features to " + str(
                    len(self.v)) + " autoencoders.")
                print("Feature-Mapper: execute-mode, Anomaly-Detector: train-mode")
        else:  # train
            ## Ensemble Layer
            S_l1 = np.zeros(len(self.ensembleLayer))
            for a in range(len(self.ensembleLayer)):
                # make sub instance for autoencoder 'a'
                xi = x[self.v[a]]
                S_l1[a] = self.ensembleLayer[a].train(xi)
            ## OutputLayer
            train_rmse = self.outputLayer.train(S_l1)
            # print(train_rmse)
            self.train_rmse.append(train_rmse)
            if self.n_trained == self.AD_grace_period + self.FM_grace_period:
                print("Feature-Mapper: execute-mode, Anomaly-Detector: execute-mode")
                print(len(self.train_rmse))
                print("The max rmse during train-mode: " + str(max(self.train_rmse)))
                import time
                time.sleep(5)
        self.n_trained += 1

    # force execute KitNET on x
    def execute(self, x):
        if self.v is None:
            raise RuntimeError(
                'KitNET Cannot execute x, because a feature mapping has not yet been learned or provided. Try running process(x) instead.')
        else:
            self.n_executed += 1
            ## Ensemble Layer
            S_l1 = np.zeros(len(self.ensembleLayer))
            for a in range(len(self.ensembleLayer)):
                # make sub inst
                xi = x[self.v[a]]
                S_l1[a] = self.ensembleLayer[a].execute(xi)     # AE的execute,返回rmse
            ## OutputLayer
            return self.outputLayer.execute(S_l1)   # 返回最后的异常分数

    def __createAD__(self):
        # 构建集成层:映射到v中各个实例的k个三层自动编码器的有序集合
        for map in self.v:
            params = AE.dA_params(n_visible=len(map), n_hidden=0, lr=self.lr, corruption_level=0, gracePeriod=0,
                                  hiddenRatio=self.hr)
            self.ensembleLayer.append(AE.dA(params))

        # 构建输出层:一个三层自动编码器，学习集成层的正常(即训练模式)均方根值。该层负责产生最终异常分数
        params = AE.dA_params(len(self.v), n_hidden=0, lr=self.lr, corruption_level=0, gracePeriod=0,
                              hiddenRatio=self.hr)
        self.outputLayer = AE.dA(params)

