import numpy
from scipy.stats import norm

numpy.seterr(all='ignore')


def pdf(x, mu, sigma):  # 正态分布的PDF
    x = (x - mu) / sigma
    return numpy.exp(-x ** 2 / 2) / (numpy.sqrt(2 * numpy.pi) * sigma)


def invLogCDF(x, mu, sigma):  # 正态分布的CDF
    x = (x - mu) / sigma
    # 注意:我们在归一化后乘以了-1，以得到更好的1-cdf
    return norm.logcdf(-x)  # note: we mutiple by -1 after normalization to better get the 1-cdf


def sigmoid(x):
    return 1. / (1 + numpy.exp(-x))


def dsigmoid(x):
    return x * (1. - x)


#  双曲正切函数
def tanh(x):
    return numpy.tanh(x)


def dtanh(x):
    return 1. - x * x


# 归一化指数函数
def softmax(x):
    e = numpy.exp(x - numpy.max(x))  # prevent overflow
    if e.ndim == 1:
        return e / numpy.sum(e, axis=0)
    else:
        return e / numpy.array([numpy.sum(e, axis=1)]).T  # ndim = 2


def ReLU(x):
    return x * (x > 0)


def dReLU(x):
    return 1. * (x > 0)


class rollmean:
    def __init__(self, k):
        self.winsize = k
        self.window = numpy.zeros(self.winsize)
        self.pointer = 0

    def apply(self, newval):
        self.window[self.pointer] = newval
        self.pointer = (self.pointer + 1) % self.winsize
        return numpy.mean(self.window)

# probability density for the Gaussian dist
# def gaussian(x, mean=0.0, scale=1.0):
#     s = 2 * numpy.power(scale, 2)
#     e = numpy.exp( - numpy.power((x - mean), 2) / s )

#     return e / numpy.square(numpy.pi * s)
